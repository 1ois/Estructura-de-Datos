
package procesos;

public class ListaSimpleCaracteres
{
    public Nodo inicio;
    
    public ListaSimpleCaracteres()
    {
        inicio = null;
    }
    
    public Nodo retornarUltimo()
    {
        Nodo p = inicio;
        
        while(p.sgte != null)
            p = p.sgte;
        
        return p;
    }
    
    public Nodo retornarAnterior(Nodo q)
    {
        Nodo p = inicio;
        
        while(p.sgte != q)
            p = p.sgte;
        
        return p;
    }
    
    public void adicionar(String dato)
    {
        Nodo nuevo, ultimo;
        
        nuevo = new Nodo();
        nuevo.info = dato;
        nuevo.sgte = null;
        
        if(inicio == null)
            inicio = nuevo;
        else
        {
            ultimo = retornarUltimo();
            ultimo.sgte = nuevo;
        }
    }
    
    public Nodo buscar(String dato)
    {
        Nodo p = inicio;
        
        while(p != null)
        {
            if(p.info.equals(dato))
                return p;
            
            p = p.sgte;
        }
        return null;
    }
    
    public void ordenar()
    {
        // implementar
    }
    
    public void insertarDespues(String dato, Nodo actual)
    {
        // implementar
    }
    
    public void insertarAntes(String dato, Nodo actual)
    {
        // implementar
    }
}
