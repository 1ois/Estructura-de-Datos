
package procesos;

public class Nodo 
{
    public double info;
    public Nodo sgte;
}
