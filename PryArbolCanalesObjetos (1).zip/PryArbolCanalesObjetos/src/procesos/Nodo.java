
package procesos;

import datos.CanalTV;

public class Nodo 
{
    public CanalTV info;
    public Nodo izq;
    public Nodo der;
}
