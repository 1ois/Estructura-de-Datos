
package procesos;

public class ArbolCaracteres
{
    private Nodo raiz;
    
    public ArbolCaracteres()
    {
        raiz = null;
    }
    
    public Nodo getRaiz()
    {
        return raiz;
    }
    
    public void insertar(String dato)
    {
        Nodo nuevo, actual, padre = null;

        nuevo = new Nodo();
            
        nuevo.info = dato;
        nuevo.izq  = null;
        nuevo.der  = null;

        if (raiz == null)
            raiz = nuevo;
        else
        {
            actual = raiz;
            while (actual != null)
            {
                padre = actual;
                if (dato.compareTo(actual.info) < 0)
                    actual = actual.izq;
                else
                    actual = actual.der;
            }
            
            if (dato.compareTo(padre.info) < 0)
                padre.izq = nuevo;
            else
                padre.der = nuevo;
        }
    }
    
    public Nodo buscar(String dato)
    {
        // completar
        return null;
    }
    
    public int contarNodos(Nodo p)
    {
        // implementar
        return 0;    // borrar esta instrucción
    }
    
    public int contarHojas(Nodo p)
    {
        // implementar
        return 0;   // borrar esta instrucción
    }    
}
