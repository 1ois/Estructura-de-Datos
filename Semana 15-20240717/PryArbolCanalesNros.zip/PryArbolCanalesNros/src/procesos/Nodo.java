
package procesos;

public class Nodo
{
    public double info;
    public Nodo izq;
    public Nodo der;
}