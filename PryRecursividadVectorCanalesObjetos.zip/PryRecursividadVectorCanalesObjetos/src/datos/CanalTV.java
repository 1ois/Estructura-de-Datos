
package datos;

public class CanalTV
{
    public int nro;
    public String nombre;
    public String pais;
}
